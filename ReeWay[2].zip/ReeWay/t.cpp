#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>
using namespace std;


int main() {
    int count=0,count_a,count_b,count_c;
    string ch;
    bool flag;
    cin>>count;
    char t[]={'{','}','(',')','[',']'};
    for(int w=0;w<count;w++)
    {
    	flag=false;
        cin>>ch;
      	char * str = new char [ch.length()+1];
      	strcpy (str, ch.c_str());
      	
        
        if(flag==true)
        {
        	cout<<"NO\n";
        }
        else
        {
        	cout<<"YES\n";
        }
        
    }
    return 0;
}
